function [grid] = lte_tool_resource_grid(enb, subframe, pdschSymbols)
%LTE_TOOL_RESOURCE_GRID Create a resource grid and map symbols
%   This helper function creates an empty DL resource grid, maps the PDSCH
%   symbols, and adds the Cell-Specific Reference Signals (CSR).

    % Create empty grid
    grid = lteDLResourceGrid(enb);

    % Get PDSCH indices for the current subframe
    pdschIndices = ltePDSCHIndices(enb, enb.PDSCH, subframe);

    % Map PDSCH symbols to the grid
    grid(pdschIndices) = pdschSymbols;

    % Generate and get indices for cell-specific reference signals
    csr = lteCellRS(enb, subframe);
    csrIndices = lteCellRSIndices(enb, subframe);

    % Map CSR symbols to the grid
    grid(csrIndices) = csr;
    
end
