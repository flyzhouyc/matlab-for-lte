function [rxWaveform, chanInfo, fadingChannel] = lte_tool_apply_channel(txWaveform, snrdB, chanMdl, samplingRate)
%LTE_TOOL_APPLY_CHANNEL Applies fading and AWGN to a waveform
%   This function simulates channel impairments by applying a fading channel
%   and adding AWGN noise.

    % Parse channel model string (e.g., 'EPA 5Hz')
    parts = strsplit(chanMdl);
    delayProfile = parts{1};
    dopplerFreq = str2double(regexprep(parts{2}, 'Hz', ''));

    % Configure fading channel
    chanCfg.DelayProfile = delayProfile;
    chanCfg.DopplerFreq = dopplerFreq;
    chanCfg.MIMOCorrelation = 'Low';
    chanCfg.Seed = 73; % for reproducibility
    chanCfg.RandomStream = 'mt19937ar with seed';
    chanCfg.SamplingRate = samplingRate;
    
    % Use a persistent channel object to maintain state across subframes
    persistent channel;
    if isempty(channel) || channel.MaximumDopplerShift ~= dopplerFreq
        channel = comm.LTEChannel(chanCfg);
    end
    
    % Apply fading channel. The channel state is maintained between calls.
    [rxFaded, chanInfo] = channel(txWaveform);
    fadingChannel = channel; % Return handle to channel object
    
    % Apply AWGN. The 'measured' flag ensures SNR is calculated based on
    % the signal power of rxFaded.
    rxWaveform = awgn(rxFaded, snrdB, 'measured');
    
end
