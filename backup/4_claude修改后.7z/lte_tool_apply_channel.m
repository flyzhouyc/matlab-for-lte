function [rxWaveform, chanInfo, fadingChannel] = lte_tool_apply_channel(txWaveform, snrdB, chanMdl, samplingRate)
%LTE_TOOL_APPLY_CHANNEL Applies fading and AWGN to a waveform.
%   [RXWAVEFORM, CHANINFO, FADINGCHANNEL] = LTE_TOOL_APPLY_CHANNEL(TXWAVEFORM,
%   SNRDB, CHANMDL, SAMPLINGRATE) simulates channel impairments by applying
%   a fading channel model and adding Additive White Gaussian Noise (AWGN).
%
%   TXWAVEFORM is the input time-domain waveform.
%   SNRDB is the desired signal-to-noise ratio in dB.
%   CHANMDL is a string defining the channel model (e.g., 'EPA 5Hz').
%   SAMPLINGRATE is the waveform sampling rate.
%
%   RXWAVEFORM is the output waveform after channel impairments.
%   CHANINFO is a structure containing information from the fading channel.
%   FADINGCHANNEL is a handle to the persistent channel object.

% Parse channel model string (e.g., 'EPA 5Hz')
parts = strsplit(chanMdl);
delayProfile = parts{1};
dopplerFreq = str2double(regexprep(parts{2}, 'Hz', ''));
    % Configure fading channel
    chanCfg.DelayProfile = delayProfile;
    chanCfg.DopplerFreq = dopplerFreq;
    chanCfg.MIMOCorrelation = 'Low';
    chanCfg.Seed = 73; % for reproducibility
    chanCfg.RandomStream = 'mt19937ar with seed';
    chanCfg.SamplingRate = samplingRate;
    
    % Use a persistent channel object to maintain state across subframes
    persistent channel;
    if isempty(channel) || channel.MaximumDopplerShift ~= dopplerFreq
        channel = comm.LTEChannel(chanCfg);
    end
    
    % Apply fading channel. The channel state is maintained between calls.
    [rxFaded, chanInfo] = channel(txWaveform);
    fadingChannel = channel; % Return handle to channel object
    
    % Apply AWGN. The 'measured' flag ensures SNR is calculated based on
    % the signal power of rxFaded.
    rxWaveform = awgn(rxFaded, snrdB, 'measured');
    
end
